//-----------------------------------------------------------------------
// <copyright file="SearchFilterOptions.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector
{
    using System;

    /// <summary>
    /// Options for filtering search.
    /// </summary>
    [Flags]
    public enum SearchFilterOptions
    {
        PropertyName = 1 << 0,
        PropertyNiceName = 1 << 1,
        TypeOfValue = 1 << 2,
        ValueToString = 1 << 3,
        ISearchFilterableInterface = 1 << 4,
        All = ~0
    }
}
#endif