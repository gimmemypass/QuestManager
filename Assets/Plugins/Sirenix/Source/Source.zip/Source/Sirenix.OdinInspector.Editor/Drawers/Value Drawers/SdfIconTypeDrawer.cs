//-----------------------------------------------------------------------
// <copyright file="SdfIconTypeDrawer.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using Sirenix.OdinInspector.Editor.Internal;
    using Sirenix.Utilities;
    using Sirenix.Utilities.Editor;
    using UnityEditor;
    using UnityEngine;

    [DrawerPriority(0, 0, 1)]
    public class SdfIconTypeDrawer : OdinValueDrawer<SdfIconType>
    {
        protected override void DrawPropertyLayout(GUIContent label)
        {
            this.ValueEntry.SmartValue = SdfIconSelector.DrawIconSelectorDropdownField(label, this.ValueEntry.SmartValue);
        }
    }
}
#endif