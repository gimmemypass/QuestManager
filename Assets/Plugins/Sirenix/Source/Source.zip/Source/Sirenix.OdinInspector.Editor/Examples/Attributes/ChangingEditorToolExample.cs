//-----------------------------------------------------------------------
// <copyright file="ChangingEditorToolExample.cs" company="Sirenix ApS">
// Copyright (c) Sirenix ApS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
#if UNITY_EDITOR
namespace Sirenix.OdinInspector.Editor.Examples
{
    [AttributeExampleDescription("Example of using EnumPaging together with OnValueChanged.")]
    [AttributeExample(typeof(EnumPagingAttribute), Order = 10)]
    [AttributeExample(typeof(OnValueChangedAttribute), Order = 10)]
    internal class ChangingEditorToolExample
    {
#if UNITY_EDITOR // UnityEditor.Tool is an editor-only type, so this example will not work in a build
        [EnumPaging, OnValueChanged("SetCurrentTool")]
        [InfoBox("Changing this property will change the current selected tool in the Unity editor.")]
        public UnityEditor.Tool sceneTool;

        private void SetCurrentTool()
        {
            UnityEditor.Tools.current = this.sceneTool;
        }
#endif
    }
}
#endif